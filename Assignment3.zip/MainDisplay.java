package onclassExcersise;
import java.util.Scanner;
final class Triangle {
    private final double base;
    private final double height;
    public Triangle(double base, double height) {
        this.base = base;
        this.height = height;
    }
    public double getBase() {
        return base;
    }
    public double getHeight() {
        return height;
    }
    public double computeArea() {
        return 0.5 * base * height;
    }
}
final class Rectangle {
    private final double width;
    private final double length;
    public Rectangle(double width, double length) {
        this.width = width;
        this.length = length;
    }
    public double getWidth() {
        return width;
    }
    public double getLength() {
        return length;
    }
    public double computeArea() {
        return width * length;
    }
}
final class Circle {
    private final double radius;
    public Circle(double radius) {
        this.radius = radius;
    }
    public double getRadius() {
        return radius;
    }
    public double computeArea() {
        return Math.PI * radius * radius;
    }
}
public class MainDisplay {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter C for Circle");
        System.out.println("Enter R for Rectangle");
        System.out.println("Enter T for Triangle");

        char choice = scanner.next().charAt(0);

        switch (choice) {
            case 'C':
                System.out.println("Enter the radius of the Circle:");
                double circleRadius = scanner.nextDouble();
                Circle circle = new Circle(circleRadius);
                System.out.printf("The area of Circle is: %.2f%n", circle.computeArea());
                break;

            case 'R':
                System.out.println("Enter the width of the Rectangle:");
                double rectWidth = scanner.nextDouble();
                System.out.println("Enter the height of the Rectangle:");
                double rectHeight = scanner.nextDouble();
                Rectangle rectangle = new Rectangle(rectWidth, rectHeight);
                System.out.printf("The area of Rectangle is: %.2f%n", rectangle.computeArea());
                break;

            case 'T':
                System.out.println("Enter the base of the Triangle:");
                double triangleBase = scanner.nextDouble();
                System.out.println("Enter the height of the Triangle:");
                double triangleHeight = scanner.nextDouble();
                Triangle triangle = new Triangle(triangleBase, triangleHeight);
                System.out.printf("The area of Triangle is: %.2f%n", triangle.computeArea());
                break;

            default:
                System.out.println("Invalid choice");
        }
        scanner.close();
    }
}
